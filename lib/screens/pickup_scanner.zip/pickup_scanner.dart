import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class PickupScannerPage extends StatefulWidget {
  const PickupScannerPage({super.key});

  @override
  State<PickupScannerPage> createState() => _PickupScannerPageState();
}

class _PickupScannerPageState extends State<PickupScannerPage> {
  final MobileScannerController controller = MobileScannerController();

  bool _loading = false;
  bool _hasScanned = false;
  bool _torchOn = false; // ✅ Manual torch state tracking
  static const Color primary = Color(0xFF7ACB9E);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Parent Pickup Verification'),
        backgroundColor: primary,
        actions: [
          // ✅ Flashlight Toggle - Manual state management
          IconButton(
            icon: Icon(
              _torchOn ? Icons.flash_on : Icons.flash_off,
              color: Colors.white,
            ),
            onPressed: () async {
              try {
                await controller.toggleTorch();
                setState(() {
                  _torchOn = !_torchOn;
                });
              } catch (e) {
                // Torch not supported on this device
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Flashlight not available'),
                    duration: Duration(seconds: 2),
                  ),
                );
              }
            },
          ),
          // Camera Switch
          IconButton(
            icon: const Icon(Icons.flip_camera_ios, color: Colors.white),
            onPressed: () => controller.switchCamera(),
          ),
        ],
      ),
      body: Stack(
        children: [
          // Full-screen scanner
          MobileScanner(
            controller: controller,
            onDetect: (capture) {
              if (_hasScanned || _loading) return;
              final barcode = capture.barcodes.firstOrNull;
              if (barcode?.rawValue != null) {
                setState(() => _hasScanned = true);
                _processPickup(barcode!.rawValue!);
              }
            },
          ),

          // QR scan frame overlay
          Center(
            child: Container(
              width: 260,
              height: 260,
              decoration: BoxDecoration(
                border: Border.all(color: primary, width: 8),
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),

          // Bottom instruction / loading
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              color: Colors.black54,
              child: _loading
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text(
                      "Scan Parent QR Code to verify pickup",
                      style: TextStyle(color: Colors.white, fontSize: 16),
                      textAlign: TextAlign.center,
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _processPickup(String qrCode) async {
    setState(() => _loading = true);

    try {
      // 1. Find parent by QR
      final parentSnap = await FirebaseFirestore.instance
          .collection('parents')
          .where('qrData', isEqualTo: qrCode)
          .limit(1)
          .get();

      if (parentSnap.docs.isEmpty) {
        _showResult(false, "QR tidak sah atau tiada dalam rekod.");
        return;
      }

      final parentData = parentSnap.docs.first.data();
      final parentName = parentData['parentName'] ?? 'Unknown';
      final childId = parentData['childId'] ?? '';
      final childName = parentData['childName'] ?? 'Unknown';
      final repName = parentData['representativeName'] ?? '-';
      final teacherName = parentData['teacherName'] ?? 'Unknown';
      final expiry = (parentData['qrExpiry'] as Timestamp?)?.toDate();

      // 2. Check QR expiry
      if (expiry == null || DateTime.now().isAfter(expiry)) {
        _showResult(false, "QR tamat tempoh! Mohon parent buat QR baharu.");
        return;
      }

      // 3. Find today's attendance
      final todayStart = DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day);
      final todayEnd = todayStart.add(const Duration(days: 1));

      final attendanceSnap = await FirebaseFirestore.instance
          .collection('attendance')
          .where('childId', isEqualTo: childId)
          .where('checkIn', isGreaterThanOrEqualTo: Timestamp.fromDate(todayStart))
          .where('checkIn', isLessThan: Timestamp.fromDate(todayEnd))
          .limit(1)
          .get();

      if (attendanceSnap.docs.isEmpty) {
        _showResult(false, "Rekod kehadiran tiada untuk hari ini.");
        return;
      }

      final attRef = attendanceSnap.docs.first.reference;

      // 4. Update checkout
      await attRef.update({
        'checkOut': FieldValue.serverTimestamp(),
        'manualCheckout': true,
        'pickupBy': repName,
        'verifiedBy': teacherName,
        'pickupAt': FieldValue.serverTimestamp(),
      });

      // 5. Log pickup
      await attRef.collection('pickup_logs').add({
        'timestamp': FieldValue.serverTimestamp(),
        'parentName': parentName,
        'representative': repName,
        'teacher': teacherName,
        'childName': childName,
      });

      // 6. Success
      _showResult(
        true,
        "Pickup Disahkan\n"
        "Parent: $parentName\n"
        "Anak: $childName\n"
        "Wakil: $repName\n"
        "Guru: $teacherName\n"
        "Masa: ${DateFormat('hh:mm a').format(DateTime.now())}",
      );
    } catch (e) {
      _showResult(false, "Ralat: ${e.toString()}");
    } finally {
      setState(() {
        _loading = false;
        _hasScanned = false;
      });
    }
  }

  void _showResult(bool success, String message) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: Text(
          success ? "Berjaya" : "Gagal",
          style: TextStyle(
            color: success ? Colors.green : Colors.red,
            fontWeight: FontWeight.bold,
          ),
        ),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              controller.start(); // Resume scanning
            },
            child: const Text("Tutup"),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }
}